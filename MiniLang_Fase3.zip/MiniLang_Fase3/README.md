# MiniLang - Proyecto Fase 3

## Tabla de símbolos y comprobación de tipos

Este proyecto implementa la tercera fase del compilador de **MiniLang** en Python. Integra el lexer y parser construidos en las fases anteriores con una nueva etapa de análisis semántico.

El compilador realiza:

- Análisis léxico.
- Análisis sintáctico.
- Construcción de AST.
- Generación de tabla de símbolos.
- Comprobación de tipos.
- Evaluación de expresiones cuando sus valores son conocidos.
- Validación de variables, constantes, funciones y parámetros.
- Recuperación de errores para continuar hasta el final del archivo.

---

## Requisitos

- Python 3.10 o superior.
- No requiere librerías externas.

El archivo `requirements.txt` se incluye únicamente como referencia.

---

## Estructura del proyecto

```text
MiniLang_Fase3/
│
├── minilang.py              # Punto de entrada del compilador
├── lexer.py                 # Analizador léxico
├── parser.py                # Analizador sintáctico y constructor de AST
├── ast_nodes.py             # Nodos del árbol abstracto de sintaxis
├── semantic_analyzer.py     # Análisis semántico y comprobación de tipos
├── symbol_table.py          # Tabla de símbolos con ámbitos
├── errors.py                # Formato común de errores
├── run_tests.py             # Ejecutor de pruebas incluidas
├── requirements.txt
│
├── pruebas/                 # 8 pruebas obligatorias de entrega
│   ├── prueba_01_hola_mundo.mlng
│   ├── prueba_02_aritmetica.mlng
│   ├── prueba_03_input_if.mlng
│   ├── prueba_04_funcion_retorno.mlng
│   ├── prueba_05_while_io.mlng
│   ├── prueba_06_error_lexico.mlng
│   ├── prueba_07_error_sintactico.mlng
│   ├── prueba_08_error_semantico.mlng
│   └── resultados_esperados.txt
│
├── tests_extra/             # Pruebas adicionales de verificación
│
└── salidas/                 # Archivos generados por el compilador
```

---

## Ejecución

Desde la carpeta del proyecto:

```bash
python minilang.py pruebas/prueba_01_hola_mundo.mlng
```

También puede ejecutarse sin argumento:

```bash
python minilang.py
```

En ese caso el programa pedirá la ruta del archivo `.mlng`:

```text
Ingrese el nombre del archivo de entrada (.mlng):
```

---

## Salidas generadas

Después de cada ejecución se generan dos archivos dentro de `salidas/`:

```text
salidas/<nombre_del_archivo>.out
salidas/tabla_simbolos.txt
```

El archivo `.out` contiene el listado de tokens reconocidos.

El archivo `tabla_simbolos.txt` contiene la tabla de símbolos completa del último archivo analizado.

Si el archivo no contiene errores, se imprime:

```text
OK
```

Si contiene errores, se imprime el listado de errores encontrados hasta llegar al final del archivo.

---

## Cómo correr todas las pruebas

```bash
python run_tests.py
```

Este script ejecuta las 8 pruebas obligatorias y las pruebas extra usadas para verificar casos adicionales.

---

## Sintaxis principal de MiniLang

MiniLang usa bloques por indentación, de forma similar a Python.

### Declaraciones

```text
int x
double precio
string nombre
bool activo
```

También se aceptan alias:

```text
float precio     # se maneja internamente como double
str nombre       # se maneja internamente como string
```

### Declaraciones múltiples

```text
int a, b, c
int x = 1, y = 2
```

### Constantes

```text
const double pi
pi = 3.1416
```

Una constante puede asignarse una vez. Si se intenta reasignar, se reporta error semántico.

### Asignaciones

```text
int resultado
resultado = 35 * 2
```

### Entrada y salida

```text
read(edad)
write(edad)
```

También se acepta:

```text
edad = read()
Write("Hola")
Read(edad)
```

`read` y `write` pueden escribirse en minúscula o con mayúscula inicial.

### Condicionales

```text
if edad >= 18:
    write("Mayor")
else:
    write("Menor")
```

### Ciclos

```text
while i < 5:
    write(i)
    i = i + 1
```

### Funciones

Se aceptan funciones con tipo de retorno:

```text
def int suma(int a, int b):
    return a + b
```

También se aceptan funciones sin tipo explícito de retorno:

```text
def imprimir(string texto):
    write(texto)
```

---

## Tipos soportados

MiniLang maneja los siguientes tipos principales:

```text
int
double
string
bool
void
```

Alias aceptados:

```text
float  -> double
str    -> string
```

---

## Reglas de comprobación de tipos

### Operaciones aritméticas

```text
int + int          -> int
int + double       -> double
double + int       -> double
double + double    -> double
```

La misma lógica aplica para `-`, `*` y `/`, con la diferencia de que `/` produce `double`.

El operador `%` solo acepta operandos `int`.

### Coerción permitida

Se permite coerción de:

```text
int -> double
```

Ejemplo válido:

```text
int A
double B
A = 9
B = 34.35 * A
```

### Operaciones con string

Se permite únicamente:

```text
string + string -> string
```

No se permite operar `string` con operadores numéricos como `*`, `/`, `-` o `%`.

### Operaciones lógicas

```text
bool and bool -> bool
bool or bool  -> bool
not bool      -> bool
```

### Comparaciones

Las comparaciones relacionales `<`, `>`, `<=`, `>=` requieren operandos numéricos.

Las comparaciones `==` y `!=` permiten operandos del mismo tipo o tipos numéricos compatibles.

---

## Tabla de símbolos

La tabla de símbolos se maneja con una pila de ámbitos. El ámbito global se crea al iniciar el análisis. Al entrar a funciones, bloques `if`, `elif`, `else` o `while`, se crea un nuevo ámbito. Al salir del bloque, el ámbito actual se elimina de la pila, pero el símbolo queda registrado en el historial para poder generar el archivo final.

Cada símbolo almacena:

```text
Nombre
Categoría
Tipo
Valor
Ámbito
Línea
Columna
Inicializada
Constante
Parámetros
Retorno
```

Categorías usadas:

```text
variable
constant
function
parameter
```

Ejemplo de símbolos que pueden aparecer:

```text
pi        constant    double    3.1416
radio     constant    double    20.5
circun    variable    double    128.8056
suma      function    function  parámetros: int a, int b   retorno: int
```

---

## Evaluación de valores

El analizador semántico intenta calcular el valor de variables y constantes cuando la expresión está compuesta por valores conocidos.

Ejemplo:

```text
const int a
a = 35 * 2
```

La tabla de símbolos guarda:

```text
a -> 70
```

Ejemplo con referencias:

```text
const double pi
const double radio
double circun

pi = 3.1416
radio = 20.5
circun = pi * 2 * radio
```

La tabla guarda el valor calculado de `circun`.

Cuando el valor viene de `read`, se marca como desconocido, pero la variable queda inicializada.

---

## Estrategia de errores

El compilador separa los errores en tres fases:

```text
lexical
syntax
semantic
```

El formato general de error es:

```text
line <n>, column <m>: ERROR <descripción>
```

Cuando aplica, también muestra el símbolo involucrado:

```text
line <n>, column <m>, symbol '<símbolo>': ERROR <descripción>
```

El compilador no se detiene en el primer error. Intenta continuar hasta EOF para mostrar la mayor cantidad de errores posible.

---

## Errores semánticos detectados

El analizador semántico detecta, entre otros:

- Variable no declarada.
- Variable usada antes de inicializarse.
- Redeclaración en el mismo ámbito.
- Reasignación de constantes.
- Asignación de tipo incompatible.
- Operaciones inválidas entre tipos incompatibles.
- Condiciones de `if`, `elif` y `while` que no son booleanas.
- Llamadas a funciones no declaradas.
- Cantidad incorrecta de argumentos.
- Tipo incorrecto en argumentos.
- Retornos incompatibles con el tipo de la función.
- Uso de una función `void` como valor.

---

## Pruebas obligatorias incluidas

| Prueba |               Archivo             |              Objetivo            | Resultado esperado |
|--------|-----------------------------------|----------------------------------|--------------------|
|    1   | `prueba_01_hola_mundo.mlng`       | Hola Mundo                       | OK                 |
|    2   | `prueba_02_aritmetica.mlng`       | Operación aritmética básica      | OK                 |
|    3   | `prueba_03_input_if.mlng`         | Input + if/else                  | OK                 |
|    4   | `prueba_04_funcion_retorno.mlng`  | Función con parámetros y retorno | OK                 |
|    5   | `prueba_05_while_io.mlng`         | Variables, salida y while        | OK                 |
|    6   | `prueba_06_error_lexico.mlng`     | Fallo léxico                     | Error léxico       |
|    7   | `prueba_07_error_sintactico.mlng` | Fallo sintáctico                 | Error sintáctico   |
|    8   | `prueba_08_error_semantico.mlng`  | Fallo semántico                  | Error semántico    |

Los resultados esperados están documentados también en:

```text
pruebas/resultados_esperados.txt
```

---

## Pruebas extra incluidas

Además de las 8 pruebas obligatorias, se agregaron pruebas internas para validar:

- Constantes y coerción.
- Declaraciones múltiples.
- Argumento inválido en función.
- Reasignación de constante.
- Uso de variable no inicializada.
- Concatenación de strings.
- Operadores lógicos.
- Asignación directa con `read()`.

Estas pruebas están en:

```text
tests_extra/
```

---

## Decisiones de diseño

1. **Se conserva MiniLang por indentación** para mantener continuidad con las fases previas.
2. **Se aceptan `str/string` y `float/double`** para ser compatible con los ejemplos de las fases anteriores y de la fase 3.
3. **Se aceptan `read/write` y `Read/Write`** para evitar errores por variación menor en los archivos de prueba.
4. **Las constantes se pueden asignar una sola vez**.
5. **Se permite coerción `int -> double`**, pero no `double -> int`.
6. **El parser construye un AST con línea y columna** para que el análisis semántico pueda reportar errores precisos.
7. **La tabla de símbolos guarda historial completo**, aunque los ámbitos se cierren durante el análisis.

---

## Comandos útiles

Ejecutar una prueba:

```bash
python minilang.py pruebas/prueba_04_funcion_retorno.mlng
```

Ejecutar todas las pruebas:

```bash
python run_tests.py
```

Ver la tabla de símbolos generada:

```text
salidas/tabla_simbolos.txt
```

## Aclaraciones

---

MiniLang en esta implementación usa una sintaxis basada en indentación, similar a Python. 
Los ejemplos del enunciado que usan llaves o estructura tipo C/Java fueron adaptados a esta gramática, siguiendo el criterio usado en fases anteriores.

---

El script principal del compilador es minilang.py. Se ejecuta con:
python minilang.py archivo.mlng

---

El analizador semántico valida los bloques de if, elif, else y while para verificar tipos y errores internos. 
Las asignaciones encontradas dentro de estos bloques actualizan la tabla de símbolos durante el análisis estático. 
No se implementa análisis de flujo de control exhaustivo para determinar si una asignación ocurre en todos los caminos posibles de ejecución.

---
