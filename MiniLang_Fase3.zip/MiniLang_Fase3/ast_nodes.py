from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class Node:
    line: int = 0
    column: int = 0


@dataclass
class Program(Node):
    statements: list[Node] = field(default_factory=list)


@dataclass
class TypeName(Node):
    name: str = ""


@dataclass
class Declaration(Node):
    var_type: str = ""
    names: list[tuple[str, Optional[Node], int, int]] = field(default_factory=list)
    is_const: bool = False


@dataclass
class Assignment(Node):
    name: str = ""
    expr: Optional[Node] = None


@dataclass
class ReadStatement(Node):
    target: Optional[str] = None


@dataclass
class WriteStatement(Node):
    expr: Optional[Node] = None


@dataclass
class ReturnStatement(Node):
    expr: Optional[Node] = None


@dataclass
class Parameter(Node):
    name: str = ""
    param_type: str = "any"


@dataclass
class FunctionDef(Node):
    name: str = ""
    return_type: str = "any"
    params: list[Parameter] = field(default_factory=list)
    body: list[Node] = field(default_factory=list)


@dataclass
class IfStatement(Node):
    condition: Optional[Node] = None
    then_body: list[Node] = field(default_factory=list)
    elif_branches: list[tuple[Node, list[Node], int, int]] = field(default_factory=list)
    else_body: Optional[list[Node]] = None


@dataclass
class WhileStatement(Node):
    condition: Optional[Node] = None
    body: list[Node] = field(default_factory=list)


@dataclass
class Literal(Node):
    value: Any = None
    typ: str = "any"


@dataclass
class Identifier(Node):
    name: str = ""


@dataclass
class BinaryOp(Node):
    op: str = ""
    left: Optional[Node] = None
    right: Optional[Node] = None


@dataclass
class UnaryOp(Node):
    op: str = ""
    expr: Optional[Node] = None


@dataclass
class FunctionCall(Node):
    name: str = ""
    args: list[Node] = field(default_factory=list)


@dataclass
class ReadCall(Node):
    pass


@dataclass
class ErrorNode(Node):
    message: str = ""
