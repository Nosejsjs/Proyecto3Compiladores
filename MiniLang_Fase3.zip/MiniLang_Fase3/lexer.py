from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from errors import CompilerError

MAX_ID_LENGTH = 31
MAX_INDENT_LEVELS = 5
TAB_SIZE = 4

TOKENS = (
    # Estructura
    'NEWLINE', 'INDENT', 'DEDENT', 'EOF',

    # Identificadores y literales
    'ID', 'INT_LITERAL', 'FLOAT_LITERAL', 'STRING_LITERAL', 'BOOL_LITERAL',

    # Tipos
    'KW_INT', 'KW_FLOAT', 'KW_DOUBLE', 'KW_STR', 'KW_STRING', 'KW_BOOL', 'KW_VOID',

    # Constantes
    'KW_CONST',

    # Control
    'KW_IF', 'KW_ELIF', 'KW_ELSE', 'KW_WHILE',

    # Funciones
    'KW_DEF', 'KW_RETURN',

    # Entrada / salida
    'KW_READ', 'KW_WRITE',

    # Lógicos
    'KW_AND', 'KW_OR', 'KW_NOT',

    # Operadores
    'ASSIGN',
    'PLUS', 'MINUS', 'TIMES', 'DIVIDE', 'MODULO',
    'EQ', 'NEQ', 'LT', 'GT', 'LTE', 'GTE',

    # Puntuación
    'LPAREN', 'RPAREN', 'COMMA', 'COLON', 'SEMI',
)

tokens = TOKENS

KEYWORDS = {
    'int': 'KW_INT',
    'float': 'KW_FLOAT',
    'double': 'KW_DOUBLE',
    'str': 'KW_STR',
    'string': 'KW_STRING',
    'bool': 'KW_BOOL',
    'void': 'KW_VOID',
    'const': 'KW_CONST',
    'if': 'KW_IF',
    'elif': 'KW_ELIF',
    'else': 'KW_ELSE',
    'while': 'KW_WHILE',
    'def': 'KW_DEF',
    'return': 'KW_RETURN',
    'read': 'KW_READ',
    'write': 'KW_WRITE',
    'and': 'KW_AND',
    'or': 'KW_OR',
    'not': 'KW_NOT',
}

BOOL_LITERALS = {
    'true': True,
    'false': False,
}

TWO_CHAR_TOKENS = {
    '==': 'EQ',
    '!=': 'NEQ',
    '<=': 'LTE',
    '>=': 'GTE',
}

ONE_CHAR_TOKENS = {
    '+': 'PLUS',
    '-': 'MINUS',
    '*': 'TIMES',
    '/': 'DIVIDE',
    '%': 'MODULO',
    '=': 'ASSIGN',
    '<': 'LT',
    '>': 'GT',
    '(': 'LPAREN',
    ')': 'RPAREN',
    ',': 'COMMA',
    ':': 'COLON',
    ';': 'SEMI',
}

ESCAPE_SEQUENCES = {
    'n': '\n',
    't': '\t',
    'r': '\r',
    '\\': '\\',
    '"': '"',
    "'": "'",
    '0': '\0',
}

NO_VALUE_TYPES = {'NEWLINE', 'INDENT', 'DEDENT', 'EOF'}


@dataclass
class Token:
    type: str
    lexeme: str
    line: int
    col_start: int
    col_end: int
    value: Any = None

    def format_output(self) -> str:
        pos = f"({self.line},{self.col_start}-{self.col_end})"
        if self.type in NO_VALUE_TYPES:
            return f"{pos} {self.type}"
        if self.type == 'STRING_LITERAL':
            return f"{pos} {self.type} {self.value!r}"
        if self.type in ('INT_LITERAL', 'FLOAT_LITERAL', 'BOOL_LITERAL'):
            return f"{pos} {self.type} {self.value}"
        return f"{pos} {self.type} '{self.lexeme}'"


class Lexer:
    """Analizador léxico manual para MiniLang

    Características principales:
    - Emite NEWLINE, INDENT y DEDENT
    - Reconoce línea, columna inicial y columna final
    - Reporta errores léxicos sin abortar
    - Acepta comentarios con #, // y bloques /* ... */
    - Acepta read/write con mayúscula inicial y booleanos true/false o True/False
    """

    def __init__(self, source: str):
        self.errors: list[CompilerError] = []
        self.source = self._remove_block_comments_preserving_layout(source)
        self.tokens: list[Token] = []
        self.indent_stack: list[int] = [0]

    def tokenize(self) -> tuple[list[Token], list[CompilerError]]:
        lines = self.source.splitlines()
        last_line = len(lines) if lines else 1

        for line_num, line in enumerate(lines, start=1):
            self._process_line(line, line_num)

        while len(self.indent_stack) > 1:
            self.indent_stack.pop()
            self._add_token('DEDENT', '', last_line, 1, 1)

        self._add_token('EOF', '', last_line, 1, 1)
        return self.tokens, self.errors

    def _remove_block_comments_preserving_layout(self, text: str) -> str:
        result: list[str] = []
        i = 0
        line = 1
        col = 1
        in_block = False
        start_line = 0
        start_col = 0

        while i < len(text):
            ch = text[i]
            nxt = text[i + 1] if i + 1 < len(text) else ''

            if not in_block and ch == '/' and nxt == '*':
                in_block = True
                start_line = line
                start_col = col
                result.extend([' ', ' '])
                i += 2
                col += 2
                continue

            if in_block and ch == '*' and nxt == '/':
                in_block = False
                result.extend([' ', ' '])
                i += 2
                col += 2
                continue

            if in_block:
                if ch == '\n':
                    result.append('\n')
                    line += 1
                    col = 1
                else:
                    result.append(' ')
                    col += 1
                i += 1
                continue

            result.append(ch)
            if ch == '\n':
                line += 1
                col = 1
            else:
                col += 1
            i += 1

        if in_block:
            self.errors.append(
                CompilerError(start_line, start_col, 'lexical', 'unclosed block comment; expected */')
            )
        return ''.join(result)

    def _process_line(self, line: str, line_num: int) -> None:
        indent_count = 0
        i = 0
        while i < len(line) and line[i] in (' ', '\t'):
            if line[i] == '\t':
                indent_count = (indent_count // TAB_SIZE + 1) * TAB_SIZE
            else:
                indent_count += 1
            i += 1

        rest = line[i:]
        if not rest or rest.lstrip() == '' or rest.lstrip().startswith('#') or rest.lstrip().startswith('//'):
            return

        top = self.indent_stack[-1]
        if indent_count > top:
            if len(self.indent_stack) >= MAX_INDENT_LEVELS + 1:
                self._add_error(
                    line_num,
                    1,
                    f"maximum indentation level ({MAX_INDENT_LEVELS}) exceeded; indentation level was ignored",
                )
            else:
                self.indent_stack.append(indent_count)
                self._add_token('INDENT', '', line_num, 1, max(1, i))
        elif indent_count < top:
            while self.indent_stack and self.indent_stack[-1] > indent_count:
                self.indent_stack.pop()
                self._add_token('DEDENT', '', line_num, 1, 1)
            if not self.indent_stack or self.indent_stack[-1] != indent_count:
                closest = self.indent_stack[-1] if self.indent_stack else 0
                self._add_error(
                    line_num,
                    1,
                    f"invalid indentation: level {indent_count} does not exist in indentation stack; synchronized to {closest}",
                )

        had_tokens = self._scan_line(line, line_num, i)
        if had_tokens:
            end_col = len(line) + 1
            self._add_token('NEWLINE', '', line_num, end_col, end_col)

    def _scan_line(self, line: str, line_num: int, start: int) -> bool:
        j = start
        n = len(line)
        has_tokens = False

        while j < n:
            ch = line[j]

            if ch in (' ', '\t'):
                j += 1
                continue

            if ch == '#':
                break

            if ch == '/' and j + 1 < n and line[j + 1] == '/':
                break

            if ch in ('"', "'"):
                tok, j = self._scan_string(line, line_num, j)
                if tok:
                    self.tokens.append(tok)
                    has_tokens = True
                continue

            if ch.isdigit():
                tok, j = self._scan_number(line, line_num, j)
                if tok:
                    self.tokens.append(tok)
                    has_tokens = True
                continue

            if ch.isalpha() or ch == '_':
                tok, j = self._scan_identifier(line, line_num, j)
                if tok:
                    self.tokens.append(tok)
                    has_tokens = True
                continue

            two = line[j:j + 2]
            if two in TWO_CHAR_TOKENS:
                col = j + 1
                self._add_token(TWO_CHAR_TOKENS[two], two, line_num, col, col + 1)
                has_tokens = True
                j += 2
                continue

            if ch in ONE_CHAR_TOKENS:
                col = j + 1
                self._add_token(ONE_CHAR_TOKENS[ch], ch, line_num, col, col)
                has_tokens = True
                j += 1
                continue


            self._add_error(line_num, j + 1, f"unexpected character '{ch}' (ASCII {ord(ch)})")
            j += 1

        return has_tokens



    def _scan_string(self, line: str, line_num: int, j: int) -> tuple[Optional[Token], int]:
        quote = line[j]
        start_col = j + 1
        j += 1
        chars: list[str] = []
        closed = False

        while j < len(line):
            ch = line[j]
            if ch == '\\' and j + 1 < len(line):
                esc = line[j + 1]
                if esc in ESCAPE_SEQUENCES:
                    chars.append(ESCAPE_SEQUENCES[esc])
                else:
                    chars.append('\\')
                    chars.append(esc)
                j += 2
            elif ch == quote:
                closed = True
                j += 1
                break
            else:
                chars.append(ch)
                j += 1

        if not closed:
            self._add_error(line_num, start_col, f"unclosed string: expected {quote} before end of line")
            return None, j

        value = ''.join(chars)
        return Token('STRING_LITERAL', f'{quote}{value}{quote}', line_num, start_col, j, value), j

    def _scan_number(self, line: str, line_num: int, j: int) -> tuple[Optional[Token], int]:
        start_col = j + 1
        chars: list[str] = []
        is_float = False

        while j < len(line) and (line[j].isdigit() or line[j] == '.'):
            if line[j] == '.':
                if is_float:
                    # Consume the malformed tail to avoid multiple confusing errors.
                    while j < len(line) and not line[j].isspace() and line[j] not in ',:;()':
                        chars.append(line[j])
                        j += 1
                    malformed = ''.join(chars)
                    self._add_error(line_num, start_col, f"malformed number '{malformed}'")
                    return None, j
                is_float = True
            chars.append(line[j])
            j += 1

        num_str = ''.join(chars)
        end_col = j

        if num_str.endswith('.'):
            self._add_error(line_num, start_col, f"malformed number '{num_str}' ends with decimal point")
            return None, j

        if is_float:
            return Token('FLOAT_LITERAL', num_str, line_num, start_col, end_col, float(num_str)), j
        return Token('INT_LITERAL', num_str, line_num, start_col, end_col, int(num_str)), j

    def _scan_identifier(self, line: str, line_num: int, j: int) -> tuple[Token, int]:
        start_col = j + 1
        chars: list[str] = []

        while j < len(line) and (line[j].isalnum() or line[j] == '_'):
            chars.append(line[j])
            j += 1

        lexeme = ''.join(chars)
        end_col = j
        lowered = lexeme.lower()

        if len(lexeme) > MAX_ID_LENGTH:
            truncated = lexeme[:MAX_ID_LENGTH]
            self._add_error(
                line_num,
                start_col,
                f"identifier '{lexeme}' exceeds {MAX_ID_LENGTH} characters; truncated to '{truncated}'",
            )
            lexeme = truncated
            lowered = lexeme.lower()
            end_col = start_col + MAX_ID_LENGTH - 1

        if lowered in BOOL_LITERALS:
            return Token('BOOL_LITERAL', lexeme, line_num, start_col, end_col, BOOL_LITERALS[lowered]), j

        token_type = KEYWORDS.get(lowered, 'ID')
        return Token(token_type, lexeme, line_num, start_col, end_col), j

    def _add_token(self, token_type: str, lexeme: str, line: int, col_start: int, col_end: int, value: Any = None) -> None:
        self.tokens.append(Token(token_type, lexeme, line, col_start, col_end, value))

    def _add_error(self, line: int, column: int, message: str) -> None:
        self.errors.append(CompilerError(line, column, 'lexical', message))
