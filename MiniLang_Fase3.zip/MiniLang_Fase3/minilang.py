from __future__ import annotations

import os
import sys
from pathlib import Path

from errors import CompilerError
from lexer import Lexer, Token
from parser import MiniLangParser
from semantic_analyzer import SemanticAnalyzer

ROOT_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT_DIR / 'salidas'


def read_source_from_cli() -> tuple[str, Path]:
    if len(sys.argv) >= 2:
        input_file = Path(sys.argv[1])
    else:
        input_file = Path(input('Ingrese el nombre del archivo de entrada (.mlng): ').strip())

    if not input_file.is_file():
        print(f"[ERROR] No se encontró el archivo: '{input_file}'")
        sys.exit(1)

    if input_file.suffix != '.mlng':
        print('[ADVERTENCIA] Se esperaba un archivo con extensión .mlng')

    try:
        return input_file.read_text(encoding='utf-8'), input_file
    except OSError as exc:
        print(f'[ERROR] No se pudo leer el archivo: {exc}')
        sys.exit(1)
 

def write_tokens_file(tokens: list[Token], input_file: Path) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_path = OUTPUT_DIR / f'{input_file.stem}.out'
    with output_path.open('w', encoding='utf-8') as f:
        for token in tokens:
            f.write(token.format_output() + '\n')
    return output_path


def print_errors(errors: list[CompilerError]) -> None:
    if not errors:
        print('OK')
        return

    print('-' * 100)
    print(f'Errores encontrados: {len(errors)}')
    print('-' * 100)
    for error in errors:
        print(error)
    print('-' * 100)




def main() -> None:
    source, input_file = read_source_from_cli()

    lexer = Lexer(source)
    tokens, lexical_errors = lexer.tokenize()
    tokens_path = write_tokens_file(tokens, input_file)

    parser = MiniLangParser()
    parse_result = parser.parse(tokens)
    syntax_errors = parse_result['errors']

    semantic_analyzer = SemanticAnalyzer()
    semantic_errors, symbol_table = semantic_analyzer.analyze(parse_result['ast'])
    symbol_path = OUTPUT_DIR / 'tabla_simbolos.txt'
    symbol_table.write_report(symbol_path)

    all_errors = lexical_errors + syntax_errors + semantic_errors
    print_errors(all_errors)
    print(f'Tokens guardados en: {os.path.relpath(tokens_path, ROOT_DIR)}')
    print(f'Tabla de símbolos guardada en: {os.path.relpath(symbol_path, ROOT_DIR)}')




if __name__ == '__main__':
    main()
