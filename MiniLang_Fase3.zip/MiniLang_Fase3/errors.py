from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CompilerError:
    """Representa un error lexico, sintáctico o semántico con ubicación."""

    line: int
    column: int
    phase: str
    message: str
    symbol: str | None = None

    def __str__(self) -> str:
        symbol_part = f", symbol '{self.symbol}'" if self.symbol else ""
        return f"line {self.line}, column {self.column}{symbol_part}: ERROR {self.message}"
