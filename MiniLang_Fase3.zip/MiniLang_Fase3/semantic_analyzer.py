from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from ast_nodes import (
    Assignment,
    BinaryOp,
    Declaration,
    FunctionCall,
    FunctionDef,
    Identifier,
    IfStatement,
    Literal,
    Node,
    Program,
    ReadCall,
    ReadStatement,
    ReturnStatement,
    UnaryOp,
    WhileStatement,
    WriteStatement,
)
from errors import CompilerError
from symbol_table import Symbol, SymbolTable

UNKNOWN = '<unknown>'
NUMERIC_TYPES = {'int', 'double'}


@dataclass
class EvalResult:
    typ: str
    value: Any = UNKNOWN
    valid: bool = True

    @property
    def has_known_value(self) -> bool:
        return self.value != UNKNOWN


class SemanticAnalyzer:
    """Analizador semántico para MiniLang.

    Valida declaraciones, ámbito, inicialización, constantes, llamadas a funciones,
    tipos de expresiones y coerción numérica int -> double. También calcula valores
    cuando las expresiones contienen únicamente literales o símbolos con valores conocidos.
    """

    def __init__(self):
        self.errors: list[CompilerError] = []
        self.symbol_table = SymbolTable()
        self.current_function: Optional[FunctionDef] = None
        self.function_return_seen: dict[str, bool] = {}

    def analyze(self, program: Program) -> tuple[list[CompilerError], SymbolTable]:
        self.errors = []
        self.symbol_table = SymbolTable()
        self.current_function = None
        self.function_return_seen = {}

        self._register_top_level_functions(program)
        for stmt in program.statements:
            self._analyze_statement(stmt)

        return self.errors, self.symbol_table

    def _register_top_level_functions(self, program: Program) -> None:
        for stmt in program.statements:
            if isinstance(stmt, FunctionDef):
                params = [(param.name, param.param_type) for param in stmt.params]
                symbol = Symbol(
                    name=stmt.name,
                    category='function',
                    typ='function',
                    scope='global',
                    line=stmt.line,
                    column=stmt.column,
                    initialized=True,
                    params=params,
                    return_type=stmt.return_type,
                )
                if not self.symbol_table.declare(symbol):
                    self._error(stmt.line, stmt.column, f"Function '{stmt.name}' is already declared in this scope")
                self.function_return_seen[stmt.name] = False

    def _analyze_statement(self, stmt: Node) -> None:
        if isinstance(stmt, Declaration):
            self._analyze_declaration(stmt)
        elif isinstance(stmt, Assignment):
            self._analyze_assignment(stmt)
        elif isinstance(stmt, ReadStatement):
            self._analyze_read(stmt)
        elif isinstance(stmt, WriteStatement):
            self._eval_expr(stmt.expr)
        elif isinstance(stmt, ReturnStatement):
            self._analyze_return(stmt)
        elif isinstance(stmt, FunctionDef):
            self._analyze_function_def(stmt)
        elif isinstance(stmt, IfStatement):
            self._analyze_if(stmt)
        elif isinstance(stmt, WhileStatement):
            self._analyze_while(stmt)
        elif isinstance(stmt, FunctionCall):
            self._eval_call(stmt, as_statement=True)

    def _analyze_block(self, body: list[Node], scope_name: str) -> None:
        self.symbol_table.enter_scope(scope_name)
        for child in body:
            self._analyze_statement(child)
        self.symbol_table.exit_scope()

    def _analyze_declaration(self, stmt: Declaration) -> None:
        for name, init_expr, line, col in stmt.names:
            symbol = Symbol(
                name=name,
                category='constant' if stmt.is_const else 'variable',
                typ=stmt.var_type,
                scope=self.symbol_table.current_scope,
                line=line,
                column=col,
                initialized=False,
                is_const=stmt.is_const,
            )
            if not self.symbol_table.declare(symbol):
                self._error(line, col, f"Identifier '{name}' is already declared in this scope")
                continue

            if init_expr is not None:
                self._assign_to_symbol(symbol, init_expr, line, col, declaration_init=True)

    def _analyze_assignment(self, stmt: Assignment) -> None:
        symbol = self.symbol_table.lookup(stmt.name)
        if symbol is None:
            self._error(stmt.line, stmt.column, f"Variable '{stmt.name}' was not declared")
            self._eval_expr(stmt.expr)
            return
        self._assign_to_symbol(symbol, stmt.expr, stmt.line, stmt.column, declaration_init=False)

    def _assign_to_symbol(self, symbol: Symbol, expr: Optional[Node], line: int, col: int, declaration_init: bool) -> None:
        if expr is None:
            return

        if symbol.category == 'function':
            self._error(line, col, f"Cannot assign a value to function '{symbol.name}'")
            return

        if symbol.is_const and symbol.initialized and not declaration_init:
            self._error(line, col, f"Constant '{symbol.name}' cannot be reassigned")
            self._eval_expr(expr)
            return

        if isinstance(expr, ReadCall):
            symbol.initialized = True
            symbol.value = UNKNOWN
            return

        result = self._eval_expr(expr)
        if not result.valid:
            return

        if not self._is_assignable(symbol.typ, result.typ):
            self._error(
                line,
                col,
                f"Cannot assign value of type '{result.typ}' to '{symbol.name}' of type '{symbol.typ}'",
            )
            return

        symbol.initialized = True
        symbol.value = self._coerce_value(result.value, result.typ, symbol.typ)

    def _analyze_read(self, stmt: ReadStatement) -> None:
        if stmt.target is None:
            return

        symbol = self.symbol_table.lookup(stmt.target)
        if symbol is None:
            self._error(stmt.line, stmt.column, f"Variable '{stmt.target}' was not declared")
            return
        if symbol.category == 'function':
            self._error(stmt.line, stmt.column, f"Cannot read input into function '{stmt.target}'")
            return
        if symbol.is_const and symbol.initialized:
            self._error(stmt.line, stmt.column, f"Constant '{stmt.target}' cannot be reassigned")
            return

        symbol.initialized = True
        symbol.value = UNKNOWN

    def _analyze_return(self, stmt: ReturnStatement) -> None:
        if self.current_function is None:
            self._error(stmt.line, stmt.column, 'Return statement is only valid inside a function')
            if stmt.expr is not None:
                self._eval_expr(stmt.expr)
            return

        expected = self.current_function.return_type
        self.function_return_seen[self.current_function.name] = True

        if expected == 'void':
            if stmt.expr is not None:
                self._error(stmt.line, stmt.column, f"Function '{self.current_function.name}' returns void and cannot return a value")
                self._eval_expr(stmt.expr)
            return

        if stmt.expr is None:
            self._error(stmt.line, stmt.column, f"Function '{self.current_function.name}' must return a value of type '{expected}'")
            return

        result = self._eval_expr(stmt.expr)
        if result.valid and expected != 'any' and not self._is_assignable(expected, result.typ):
            self._error(
                stmt.line,
                stmt.column,
                f"Function '{self.current_function.name}' must return '{expected}', but expression has type '{result.typ}'",
            )

    def _analyze_function_def(self, stmt: FunctionDef) -> None:
        if self.symbol_table.current_scope != 'global':
            self._error(stmt.line, stmt.column, 'Function definitions are only allowed in global scope')
            return

        previous_function = self.current_function
        self.current_function = stmt
        self.symbol_table.enter_scope(f'function:{stmt.name}')

        seen_params: set[str] = set()
        for param in stmt.params:
            if param.name in seen_params:
                self._error(param.line, param.column, f"Parameter '{param.name}' is already declared in function '{stmt.name}'")
                continue
            seen_params.add(param.name)
            self.symbol_table.declare(
                Symbol(
                    name=param.name,
                    category='parameter',
                    typ=param.param_type,
                    scope=self.symbol_table.current_scope,
                    line=param.line,
                    column=param.column,
                    initialized=True,
                    value=UNKNOWN,
                )
            )

        for child in stmt.body:
            self._analyze_statement(child)

        if stmt.return_type not in ('void', 'any') and not self.function_return_seen.get(stmt.name, False):
            self._error(stmt.line, stmt.column, f"Function '{stmt.name}' must contain a return statement of type '{stmt.return_type}'")

        self.symbol_table.exit_scope()
        self.current_function = previous_function

    def _analyze_if(self, stmt: IfStatement) -> None:
        condition = self._eval_expr(stmt.condition)
        if condition.valid and condition.typ != 'bool':
            self._error(stmt.line, stmt.column, f"If condition must be 'bool', not '{condition.typ}'")

        self._analyze_block(stmt.then_body, f'if@{stmt.line}:{stmt.column}')
        for condition_expr, body, line, col in stmt.elif_branches:
            result = self._eval_expr(condition_expr)
            if result.valid and result.typ != 'bool':
                self._error(line, col, f"Elif condition must be 'bool', not '{result.typ}'")
            self._analyze_block(body, f'elif@{line}:{col}')
        if stmt.else_body is not None:
            self._analyze_block(stmt.else_body, f'else@{stmt.line}:{stmt.column}')

    def _analyze_while(self, stmt: WhileStatement) -> None:
        condition = self._eval_expr(stmt.condition)
        if condition.valid and condition.typ != 'bool':
            self._error(stmt.line, stmt.column, f"While condition must be 'bool', not '{condition.typ}'")
        self._analyze_block(stmt.body, f'while@{stmt.line}:{stmt.column}')

    def _eval_expr(self, expr: Optional[Node]) -> EvalResult:
        if expr is None:
            return EvalResult('any', UNKNOWN, False)

        if isinstance(expr, Literal):
            return EvalResult(expr.typ, expr.value, True)

        if isinstance(expr, Identifier):
            symbol = self.symbol_table.lookup(expr.name)
            if symbol is None:
                self._error(expr.line, expr.column, f"Variable '{expr.name}' was not declared")
                return EvalResult('any', UNKNOWN, False)
            if symbol.category == 'function':
                self._error(expr.line, expr.column, f"Function '{expr.name}' cannot be used as a variable")
                return EvalResult('any', UNKNOWN, False)
            if not symbol.initialized:
                self._error(expr.line, expr.column, f"Variable '{expr.name}' has not been initialized")
                return EvalResult(symbol.typ, UNKNOWN, False)
            return EvalResult(symbol.typ, symbol.value, True)

        if isinstance(expr, ReadCall):
            return EvalResult('input', UNKNOWN, True)

        if isinstance(expr, UnaryOp):
            return self._eval_unary(expr)

        if isinstance(expr, BinaryOp):
            return self._eval_binary(expr)

        if isinstance(expr, FunctionCall):
            return self._eval_call(expr, as_statement=False)

        return EvalResult('any', UNKNOWN, False)

    def _eval_unary(self, expr: UnaryOp) -> EvalResult:
        value = self._eval_expr(expr.expr)
        if not value.valid:
            return value

        if expr.op == 'not':
            if value.typ != 'bool':
                self._error(expr.line, expr.column, f"Operator 'not' requires 'bool', not '{value.typ}'")
                return EvalResult('bool', UNKNOWN, False)
            return EvalResult('bool', (not value.value) if value.has_known_value else UNKNOWN, True)

        if expr.op in ('+', '-'):
            if value.typ not in NUMERIC_TYPES:
                self._error(expr.line, expr.column, f"Unary operator '{expr.op}' requires numeric type, not '{value.typ}'")
                return EvalResult(value.typ, UNKNOWN, False)
            if value.has_known_value:
                return EvalResult(value.typ, +value.value if expr.op == '+' else -value.value, True)
            return EvalResult(value.typ, UNKNOWN, True)

        return EvalResult('any', UNKNOWN, False)

    def _eval_binary(self, expr: BinaryOp) -> EvalResult:
        left = self._eval_expr(expr.left)
        right = self._eval_expr(expr.right)
        if not left.valid or not right.valid:
            return EvalResult('any', UNKNOWN, False)

        if left.typ == 'input' or right.typ == 'input':
            self._error(expr.line, expr.column, 'read() can only be assigned directly to a variable')
            return EvalResult('any', UNKNOWN, False)

        if expr.op in ('and', 'or'):
            if left.typ != 'bool' or right.typ != 'bool':
                self._error(expr.line, expr.column, f"Cannot operate type '{left.typ}' and '{right.typ}' with '{expr.op}'")
                return EvalResult('bool', UNKNOWN, False)
            if left.has_known_value and right.has_known_value:
                value = left.value and right.value if expr.op == 'and' else left.value or right.value
            else:
                value = UNKNOWN
            return EvalResult('bool', value, True)

        if expr.op in ('==', '!=', '<', '>', '<=', '>='):
            return self._eval_comparison(expr, left, right)

        if expr.op in ('+', '-', '*', '/', '%'):
            return self._eval_arithmetic(expr, left, right)

        return EvalResult('any', UNKNOWN, False)

    def _eval_comparison(self, expr: BinaryOp, left: EvalResult, right: EvalResult) -> EvalResult:
        if expr.op in ('==', '!='):
            if not self._types_compatible_for_equality(left.typ, right.typ):
                self._error(expr.line, expr.column, f"Cannot compare type '{left.typ}' and '{right.typ}'")
                return EvalResult('bool', UNKNOWN, False)
        else:
            if left.typ not in NUMERIC_TYPES or right.typ not in NUMERIC_TYPES:
                self._error(expr.line, expr.column, f"Cannot compare type '{left.typ}' and '{right.typ}' with '{expr.op}'")
                return EvalResult('bool', UNKNOWN, False)

        if left.has_known_value and right.has_known_value:
            try:
                value = {
                    '==': left.value == right.value,
                    '!=': left.value != right.value,
                    '<': left.value < right.value,
                    '>': left.value > right.value,
                    '<=': left.value <= right.value,
                    '>=': left.value >= right.value,
                }[expr.op]
            except Exception:
                value = UNKNOWN
        else:
            value = UNKNOWN
        return EvalResult('bool', value, True)

    def _eval_arithmetic(self, expr: BinaryOp, left: EvalResult, right: EvalResult) -> EvalResult:
        if expr.op == '+' and left.typ == 'string' and right.typ == 'string':
            value = (left.value + right.value) if left.has_known_value and right.has_known_value else UNKNOWN
            return EvalResult('string', value, True)

        if left.typ not in NUMERIC_TYPES or right.typ not in NUMERIC_TYPES:
            self._error(expr.line, expr.column, f"Cannot operate type '{left.typ}' and '{right.typ}'")
            return EvalResult('any', UNKNOWN, False)

        if expr.op == '%' and (left.typ != 'int' or right.typ != 'int'):
            self._error(expr.line, expr.column, "Operator '%' requires both operands to be 'int'")
            return EvalResult('int', UNKNOWN, False)

        result_type = 'double' if expr.op == '/' or left.typ == 'double' or right.typ == 'double' else 'int'

        if left.has_known_value and right.has_known_value:
            try:
                if expr.op in ('/', '%') and right.value == 0:
                    self._error(expr.line, expr.column, 'Division by zero')
                    return EvalResult(result_type, UNKNOWN, False)
                value = {
                    '+': left.value + right.value,
                    '-': left.value - right.value,
                    '*': left.value * right.value,
                    '/': left.value / right.value,
                    '%': left.value % right.value,
                }[expr.op]
                if result_type == 'int' and isinstance(value, float):
                    value = int(value)
            except Exception:
                value = UNKNOWN
        else:
            value = UNKNOWN

        return EvalResult(result_type, value, True)

    def _eval_call(self, call: FunctionCall, as_statement: bool) -> EvalResult:
        symbol = self.symbol_table.lookup(call.name)
        if symbol is None or symbol.category != 'function':
            self._error(call.line, call.column, f"Function '{call.name}' was not declared")
            for arg in call.args:
                self._eval_expr(arg)
            return EvalResult('any', UNKNOWN, False)

        expected_params = symbol.params
        if len(call.args) != len(expected_params):
            self._error(
                call.line,
                call.column,
                f"Function '{call.name}' expects {len(expected_params)} argument(s), but got {len(call.args)}",
            )

        for index, arg in enumerate(call.args):
            result = self._eval_expr(arg)
            if index >= len(expected_params) or not result.valid:
                continue
            param_name, expected_type = expected_params[index]
            if expected_type != 'any' and not self._is_assignable(expected_type, result.typ):
                self._error(
                    arg.line,
                    arg.column,
                    f"Argument {index + 1} for function '{call.name}' is invalid: expected '{expected_type}', got '{result.typ}'",
                )

        return_type = symbol.return_type or 'any'
        if return_type == 'void' and not as_statement:
            self._error(call.line, call.column, f"Function '{call.name}' returns void and cannot be used as a value")
            return EvalResult('void', UNKNOWN, False)
        return EvalResult(return_type, UNKNOWN, True)

    @staticmethod
    def _types_compatible_for_equality(left: str, right: str) -> bool:
        if left == right:
            return True
        return left in NUMERIC_TYPES and right in NUMERIC_TYPES

    @staticmethod
    def _is_assignable(target_type: str, source_type: str) -> bool:
        if target_type == 'any' or source_type == 'any':
            return True
        if source_type == 'input':
            return True
        if target_type == source_type:
            return True
        if target_type == 'double' and source_type == 'int':
            return True
        return False

    @staticmethod
    def _coerce_value(value: Any, source_type: str, target_type: str) -> Any:
        if value == UNKNOWN:
            return UNKNOWN
        if target_type == 'double' and source_type == 'int':
            return float(value)
        return value

    def _error(self, line: int, column: int, message: str) -> None:
        self.errors.append(CompilerError(line, column, 'semantic', message))
