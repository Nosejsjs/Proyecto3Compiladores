from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass
class Symbol:
    name: str
    category: str
    typ: str
    scope: str
    line: int
    column: int
    value: Any = None
    initialized: bool = False
    is_const: bool = False
    params: list[tuple[str, str]] = field(default_factory=list)
    return_type: Optional[str] = None

    def value_as_text(self) -> str:
        if self.value is None:
            return '-'
        return repr(self.value) if isinstance(self.value, str) else str(self.value)

    def params_as_text(self) -> str:
        if not self.params:
            return '-'
        return ', '.join(f'{typ} {name}' for name, typ in self.params)


class SymbolTable:
    """Tabla de símbolos con pila de ámbitos y registro histórico completo."""

    def __init__(self):
        self.scopes: list[dict[str, Symbol]] = [{}]
        self.scope_names: list[str] = ['global']
        self.history: list[Symbol] = []

    @property
    def current_scope(self) -> str:
        return '::'.join(self.scope_names)

    def enter_scope(self, name: str) -> None:
        self.scopes.append({})
        self.scope_names.append(name)

    def exit_scope(self) -> None:
        if len(self.scopes) > 1:
            self.scopes.pop()
            self.scope_names.pop()

    def declare(self, symbol: Symbol) -> bool:
        current = self.scopes[-1]
        if symbol.name in current:
            return False
        current[symbol.name] = symbol
        self.history.append(symbol)
        return True

    def lookup_current(self, name: str) -> Optional[Symbol]:
        return self.scopes[-1].get(name)

    def lookup(self, name: str) -> Optional[Symbol]:
        for scope in reversed(self.scopes):
            if name in scope:
                return scope[name]
        return None

    def write_report(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        headers = [
            'Nombre', 'Categoría', 'Tipo', 'Valor', 'Ámbito', 'Línea', 'Columna',
            'Inicializada', 'Constante', 'Parámetros', 'Retorno'
        ]
        rows = []
        for sym in self.history:
            rows.append([
                sym.name,
                sym.category,
                sym.typ,
                sym.value_as_text(),
                sym.scope,
                str(sym.line),
                str(sym.column),
                'sí' if sym.initialized else 'no',
                'sí' if sym.is_const else 'no',
                sym.params_as_text(),
                sym.return_type or '-',
            ])

        widths = [len(h) for h in headers]
        for row in rows:
            for i, cell in enumerate(row):
                widths[i] = max(widths[i], len(cell))

        line = '+-' + '-+-'.join('-' * w for w in widths) + '-+'
        with path.open('w', encoding='utf-8') as f:
            f.write('TABLA DE SÍMBOLOS - MINILANG FASE 3\n')
            f.write('=' * 120 + '\n')
            f.write(line + '\n')
            f.write('| ' + ' | '.join(headers[i].ljust(widths[i]) for i in range(len(headers))) + ' |\n')
            f.write(line + '\n')
            for row in rows:
                f.write('| ' + ' | '.join(row[i].ljust(widths[i]) for i in range(len(row))) + ' |\n')
            f.write(line + '\n')

            f.write('\nNotas:\n')
            f.write('- La columna Ámbito muestra la ruta dinámica donde se declaró el símbolo.\n')
            f.write('- Las funciones guardan sus parámetros y tipo de retorno.\n')
            f.write('- Las constantes se marcan como Constante = sí y solo pueden asignarse una vez.\n')
