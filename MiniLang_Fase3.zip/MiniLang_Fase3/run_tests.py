from __future__ import annotations

from pathlib import Path

from lexer import Lexer
from parser import MiniLangParser
from semantic_analyzer import SemanticAnalyzer

ROOT = Path(__file__).resolve().parent
TEST_DIRS = [ROOT / 'pruebas', ROOT / 'tests_extra']


def run_file(path: Path) -> tuple[bool, list[str]]:
    source = path.read_text(encoding='utf-8')
    tokens, lex_errors = Lexer(source).tokenize()
    parse_result = MiniLangParser().parse(tokens)
    semantic_errors, _ = SemanticAnalyzer().analyze(parse_result['ast'])
    errors = lex_errors + parse_result['errors'] + semantic_errors
    return len(errors) == 0, [str(error) for error in errors]


def main() -> None:
    total = 0
    ok_count = 0
    for test_dir in TEST_DIRS:
        for path in sorted(test_dir.glob('*.mlng')):
            total += 1
            ok, errors = run_file(path)
            status = 'OK' if ok else f'{len(errors)} error(es) esperado(s)/detectado(s)'
            print(f'{path.relative_to(ROOT)} -> {status}')
            for error in errors:
                print(f'  {error}')
            if ok:
                ok_count += 1
    print('-' * 100)
    print(f'Archivos ejecutados: {total}')
    print(f'Archivos sin errores: {ok_count}')
    print(f'Archivos con errores detectados: {total - ok_count}')


if __name__ == '__main__':
    main()
