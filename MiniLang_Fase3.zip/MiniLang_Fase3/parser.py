from __future__ import annotations

from ast_nodes import (
    Assignment,
    BinaryOp,
    Declaration,
    ErrorNode,
    FunctionCall,
    FunctionDef,
    Identifier,
    IfStatement,
    Literal,
    Parameter,
    Program,
    ReadCall,
    ReadStatement,
    ReturnStatement,
    UnaryOp,
    WhileStatement,
    WriteStatement,
)
from errors import CompilerError
from lexer import Token

TYPE_TOKENS = {'KW_INT', 'KW_FLOAT', 'KW_DOUBLE', 'KW_STR', 'KW_STRING', 'KW_BOOL'}
RETURN_TYPE_TOKENS = TYPE_TOKENS | {'KW_VOID'}
COMPARISON_TOKENS = {'EQ', 'NEQ', 'LT', 'GT', 'LTE', 'GTE'}
COMPARISON_OPS = {'EQ': '==', 'NEQ': '!=', 'LT': '<', 'GT': '>', 'LTE': '<=', 'GTE': '>='}
ADD_OPS = {'PLUS': '+', 'MINUS': '-'}
MUL_OPS = {'TIMES': '*', 'DIVIDE': '/', 'MODULO': '%'}


class MiniLangParser:
    """Parser de MiniLang con recuperación de errores y construcción de AST

    La implementacion consume la lista de tokens generada por el lexer de fases anteriores,
    respeta NEWLINE/INDENT/DEDENT y aplica precedencia de operadores mediante funciones
    recursivas por nivel de precedencia.
    """

    def __init__(self):
        self.tokens: list[Token] = []
        self.index = 0
        self.errors: list[CompilerError] = []

    def parse(self, token_list: list[Token]) -> dict:
        self.tokens = token_list
        self.index = 0
        self.errors = []
        statements = self._parse_statement_list(stop_tokens={'EOF'})
        if not self._check('EOF'):
            self._synchronize({'EOF'})
        eof = self._peek()
        ast = Program(statements[0].line if statements else eof.line, statements[0].column if statements else eof.col_start, statements)
        return {'ast': ast, 'errors': self.errors, 'ok': len(self.errors) == 0}

    # Utilidades de tokens
    def _peek(self, offset: int = 0) -> Token:
        pos = min(self.index + offset, len(self.tokens) - 1)
        return self.tokens[pos]

    def _previous(self) -> Token:
        return self.tokens[max(0, self.index - 1)]

    def _check(self, *types: str) -> bool:
        return self._peek().type in types

    def _advance(self) -> Token:
        tok = self._peek()
        if self.index < len(self.tokens):
            self.index += 1
        return tok

    def _match(self, *types: str) -> Token | None:
        if self._check(*types):
            return self._advance()
        return None

    def _expect(self, token_type: str, message: str) -> Token | None:
        if self._check(token_type):
            return self._advance()
        tok = self._peek()
        self._error(tok, message)
        return None

    def _error(self, tok: Token, message: str) -> None:
        symbol = tok.lexeme if tok.lexeme else tok.type
        self.errors.append(CompilerError(tok.line, tok.col_start, 'syntax', message, symbol))

    def _synchronize(self, stop_tokens: set[str]) -> None:
        while not self._check('EOF') and not self._check(*stop_tokens):
            self._advance()

    def _consume_line_end(self) -> None:
        self._match('SEMI')
        if self._check('NEWLINE'):
            self._advance()
            return
        if self._check('EOF', 'DEDENT'):
            return
        tok = self._peek()
        self._error(tok, 'expected end of line')
        self._synchronize({'NEWLINE', 'DEDENT', 'EOF'})
        self._match('NEWLINE')


    @staticmethod
    def _canonical_type(tok: Token) -> str:
        value = tok.lexeme.lower()
        if value in ('str', 'string'):
            return 'string'
        if value in ('float', 'double'):
            return 'double'
        return value

    # Sentencias
    def _parse_statement_list(self, stop_tokens: set[str]) -> list:
        statements = []
        while not self._check('EOF') and not self._check(*stop_tokens):
            if self._match('NEWLINE'):
                continue
            stmt = self._parse_statement()
            if not isinstance(stmt, ErrorNode):
                statements.append(stmt)
        return statements 

    def _parse_statement(self):
        try:
            if self._check('KW_DEF'):
                return self._parse_function_def()
            if self._check('KW_IF'):
                return self._parse_if()
            if self._check('KW_WHILE'):
                return self._parse_while()
            return self._parse_simple_statement()
        except Exception:
            tok = self._peek()
            self._error(tok, 'invalid statement')
            self._synchronize({'NEWLINE', 'DEDENT', 'EOF'})
            self._match('NEWLINE')
            return ErrorNode(tok.line, tok.col_start, 'invalid statement')

    def _parse_simple_statement(self):
        if self._check('KW_CONST') or self._check(*TYPE_TOKENS):
            stmt = self._parse_declaration()
            self._consume_line_end()
            return stmt

        if self._check('ID') and self._peek(1).type == 'ASSIGN':
            stmt = self._parse_assignment()
            self._consume_line_end()
            return stmt

        if self._check('ID') and self._peek(1).type == 'LPAREN':
            stmt = self._parse_function_call()
            self._consume_line_end()
            return stmt

        if self._check('KW_WRITE'):
            stmt = self._parse_write()
            self._consume_line_end()
            return stmt

        if self._check('KW_READ'):
            # read(x) como sentencia; read() como sentencia también se acepta.
            start = self._advance()
            self._expect('LPAREN', "expected '(' after read")
            target = None
            if self._check('ID'):
                target = self._advance().lexeme
            self._expect('RPAREN', "expected ')' after read")
            self._consume_line_end()
            return ReadStatement(start.line, start.col_start, target)

        if self._check('KW_RETURN'):
            stmt = self._parse_return()
            self._consume_line_end()
            return stmt

        tok = self._peek()
        self._error(tok, 'unexpected statement')
        self._synchronize({'NEWLINE', 'DEDENT', 'EOF'})
        self._match('NEWLINE')
        return ErrorNode(tok.line, tok.col_start, 'unexpected statement')


    def _parse_declaration(self) -> Declaration:
        is_const = self._match('KW_CONST') is not None
        type_tok = self._expect_type()
        var_type = self._canonical_type(type_tok) if type_tok else 'any'
        names = []

        first_id = self._expect('ID', 'expected identifier in declaration')
        if first_id:
            init = None
            if self._match('ASSIGN'):
                init = self._parse_expression()
            names.append((first_id.lexeme, init, first_id.line, first_id.col_start))

        while self._match('COMMA'):
            id_tok = self._expect('ID', 'expected identifier after comma')
            if id_tok:
                init = None
                if self._match('ASSIGN'):
                    init = self._parse_expression()
                names.append((id_tok.lexeme, init, id_tok.line, id_tok.col_start))

        line = names[0][2] if names else (type_tok.line if type_tok else 0)
        col = names[0][3] if names else (type_tok.col_start if type_tok else 0)
        return Declaration(line, col, var_type, names, is_const)

    def _expect_type(self) -> Token | None:
        if self._check(*TYPE_TOKENS):
            return self._advance()
        tok = self._peek()
        self._error(tok, 'expected type')
        return None

    def _parse_assignment(self) -> Assignment:
        name_tok = self._advance()
        self._expect('ASSIGN', "expected '=' in assignment")
        expr = self._parse_expression()
        return Assignment(name_tok.line, name_tok.col_start, name_tok.lexeme, expr)

    def _parse_write(self) -> WriteStatement:
        start = self._advance()
        self._expect('LPAREN', "expected '(' after write")
        expr = self._parse_expression()
        self._expect('RPAREN', "expected ')' after write")
        return WriteStatement(start.line, start.col_start, expr)

    def _parse_return(self) -> ReturnStatement:
        start = self._advance()
        if self._check('NEWLINE', 'SEMI', 'DEDENT', 'EOF'):
            return ReturnStatement(start.line, start.col_start, None)
        return ReturnStatement(start.line, start.col_start, self._parse_expression())

    def _parse_function_def(self) -> FunctionDef:
        start = self._expect('KW_DEF', "expected 'def'")
        return_type = 'any'
        if self._check(*RETURN_TYPE_TOKENS):
            type_tok = self._advance()
            return_type = self._canonical_type(type_tok)
        name_tok = self._expect('ID', 'expected function name')
        self._expect('LPAREN', "expected '(' after function name")
        params = self._parse_params()
        self._expect('RPAREN', "expected ')' after parameters")
        self._expect('COLON', "expected ':' after function header")
        self._expect('NEWLINE', 'expected newline after function header')
        body = self._parse_block()
        name = name_tok.lexeme if name_tok else '<error>'
        return FunctionDef(start.line if start else 0, start.col_start if start else 0, name, return_type, params, body)

    def _parse_params(self) -> list[Parameter]:
        params: list[Parameter] = []
        if self._check('RPAREN'):
            return params
        while True:
            param_type = 'any'
            if self._check(*TYPE_TOKENS):
                type_tok = self._advance()
                param_type = self._canonical_type(type_tok)
            name_tok = self._expect('ID', 'expected parameter name')
            if name_tok:
                params.append(Parameter(name_tok.line, name_tok.col_start, name_tok.lexeme, param_type))
            if not self._match('COMMA'):
                break
        return params

    def _parse_if(self) -> IfStatement:
        start = self._expect('KW_IF', "expected 'if'")
        condition = self._parse_expression()
        self._expect('COLON', "expected ':' after if condition")
        self._expect('NEWLINE', 'expected newline after if header')
        then_body = self._parse_block()
        elifs = []
        while self._check('KW_ELIF'):
            elif_tok = self._advance()
            elif_cond = self._parse_expression()
            self._expect('COLON', "expected ':' after elif condition")
            self._expect('NEWLINE', 'expected newline after elif header')
            elif_body = self._parse_block()
            elifs.append((elif_cond, elif_body, elif_tok.line, elif_tok.col_start))
        else_body = None
        if self._check('KW_ELSE'):
            self._advance()
            self._expect('COLON', "expected ':' after else")
            self._expect('NEWLINE', 'expected newline after else')
            else_body = self._parse_block()
        return IfStatement(start.line if start else 0, start.col_start if start else 0, condition, then_body, elifs, else_body)

    def _parse_while(self) -> WhileStatement:
        start = self._expect('KW_WHILE', "expected 'while'")
        condition = self._parse_expression()
        self._expect('COLON', "expected ':' after while condition")
        self._expect('NEWLINE', 'expected newline after while header')
        body = self._parse_block()
        return WhileStatement(start.line if start else 0, start.col_start if start else 0, condition, body)

    def _parse_block(self) -> list:
        if not self._match('INDENT'):
            tok = self._peek()
            self._error(tok, 'expected indented block')
            return []
        body = self._parse_statement_list(stop_tokens={'DEDENT'})
        self._expect('DEDENT', 'expected end of indented block')
        return body

    # Expresiones con precedencia
    def _parse_expression(self):
        return self._parse_or()

    def _parse_or(self):
        expr = self._parse_and()
        while self._match('KW_OR'):
            op = self._previous()
            right = self._parse_and()
            expr = BinaryOp(op.line, op.col_start, 'or', expr, right)
        return expr

    def _parse_and(self):
        expr = self._parse_not()
        while self._match('KW_AND'):
            op = self._previous()
            right = self._parse_not()
            expr = BinaryOp(op.line, op.col_start, 'and', expr, right)
        return expr

    def _parse_not(self):
        if self._match('KW_NOT'):
            op = self._previous()
            return UnaryOp(op.line, op.col_start, 'not', self._parse_not())
        return self._parse_comparison()

    def _parse_comparison(self):
        expr = self._parse_additive()
        if self._check(*COMPARISON_TOKENS):
            op_tok = self._advance()
            right = self._parse_additive()
            expr = BinaryOp(op_tok.line, op_tok.col_start, COMPARISON_OPS[op_tok.type], expr, right)
        return expr

    def _parse_additive(self):
        expr = self._parse_multiplicative()
        while self._check(*ADD_OPS.keys()):
            op_tok = self._advance()
            right = self._parse_multiplicative()
            expr = BinaryOp(op_tok.line, op_tok.col_start, ADD_OPS[op_tok.type], expr, right)
        return expr

    def _parse_multiplicative(self):
        expr = self._parse_unary()
        while self._check(*MUL_OPS.keys()):
            op_tok = self._advance()
            right = self._parse_unary()
            expr = BinaryOp(op_tok.line, op_tok.col_start, MUL_OPS[op_tok.type], expr, right)
        return expr

    def _parse_unary(self):
        if self._check('PLUS', 'MINUS'):
            op_tok = self._advance()
            return UnaryOp(op_tok.line, op_tok.col_start, ADD_OPS[op_tok.type], self._parse_unary())
        return self._parse_primary()

    def _parse_primary(self):
        if self._check('INT_LITERAL'):
            tok = self._advance()
            return Literal(tok.line, tok.col_start, tok.value, 'int')
        if self._check('FLOAT_LITERAL'):
            tok = self._advance()
            return Literal(tok.line, tok.col_start, tok.value, 'double')
        if self._check('STRING_LITERAL'):
            tok = self._advance()
            return Literal(tok.line, tok.col_start, tok.value, 'string')
        if self._check('BOOL_LITERAL'):
            tok = self._advance()
            return Literal(tok.line, tok.col_start, tok.value, 'bool')
        if self._check('ID'):
            if self._peek(1).type == 'LPAREN':
                return self._parse_function_call()
            tok = self._advance()
            return Identifier(tok.line, tok.col_start, tok.lexeme)
        if self._check('KW_READ'):
            start = self._advance()
            self._expect('LPAREN', "expected '(' after read")
            self._expect('RPAREN', "expected ')' after read")
            return ReadCall(start.line, start.col_start)
        if self._match('LPAREN'):
            expr = self._parse_expression()
            self._expect('RPAREN', "expected ')' after expression")
            return expr

        tok = self._peek()
        self._error(tok, 'expected expression')
        self._advance()
        return ErrorNode(tok.line, tok.col_start, 'expected expression')

    def _parse_function_call(self) -> FunctionCall:
        name_tok = self._expect('ID', 'expected function name')
        self._expect('LPAREN', "expected '(' after function name")
        args = []
        if not self._check('RPAREN'):
            while True:
                args.append(self._parse_expression())
                if not self._match('COMMA'):
                    break
        self._expect('RPAREN', "expected ')' after arguments")
        return FunctionCall(name_tok.line if name_tok else 0, name_tok.col_start if name_tok else 0, name_tok.lexeme if name_tok else '<error>', args)
